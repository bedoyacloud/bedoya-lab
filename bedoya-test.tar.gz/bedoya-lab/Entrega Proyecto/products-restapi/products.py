products = [
    {"name": "laptop", "price": 800, "quantity": 4 },
    {"name": "mouse", "price": 40, "quantity": 10 },
    {"name": "monitor", "price": 400, "quantity": 3 },
]